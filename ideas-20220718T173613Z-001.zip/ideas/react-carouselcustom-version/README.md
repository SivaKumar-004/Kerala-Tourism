# React Carousel - Custom version

A Pen created on CodePen.io. Original URL: [https://codepen.io/fcgomes92/pen/YNmWay](https://codepen.io/fcgomes92/pen/YNmWay).

Just trying out the CSSTransitionGroup add-on!
And testing some stuff (=
Original one: http://codepen.io/andyNroses/pen/KaENLb