# Responsive Slideshow / Carousel with only HTML5 & CSS3

A Pen created on CodePen.io. Original URL: [https://codepen.io/trungk18/pen/EydyoL](https://codepen.io/trungk18/pen/EydyoL).

An image slider with next/previous buttons, nav dots and image transitions using only HTML5 and CSS3