# Glassmorphism Side Navbar With HTML & CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/NikhilBobade/pen/LYWbexW](https://codepen.io/NikhilBobade/pen/LYWbexW).

