# 3D Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/ZEJLapj](https://codepen.io/ykadosh/pen/ZEJLapj).

This is a simple carousel react component, that utilizes CSS transformations to create this 3D effect.

The cards are rotated, translated and blurred based on their distance in the list from the active card. Additionally, the color of the card is changing to be darker while maintaining the same hue using hsl().