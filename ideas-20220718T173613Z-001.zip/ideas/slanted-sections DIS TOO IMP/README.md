# Slanted Sections

A Pen created on CodePen.io. Original URL: [https://codepen.io/quinlo/pen/gZeGra](https://codepen.io/quinlo/pen/gZeGra).

Have seen slanted sections in my travels around the web and wanted to take a stab at it.  This one was fun because I had to dust off the cobwebs on my trigonometry!  As with most web-codings, there probably are a dozen different ways to do this, here is mine:) 