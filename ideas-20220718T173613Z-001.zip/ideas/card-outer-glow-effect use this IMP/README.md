# Card Outer GLow Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/lincohn/pen/JjPZgXw](https://codepen.io/lincohn/pen/JjPZgXw).

