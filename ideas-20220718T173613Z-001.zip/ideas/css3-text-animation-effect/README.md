# CSS3 Text Animation Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Sonick/pen/AwXJdM](https://codepen.io/Sonick/pen/AwXJdM).

