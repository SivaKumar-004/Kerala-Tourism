# CSS3 text-shadow effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/juanbrujo/pen/DBKxxM](https://codepen.io/juanbrujo/pen/DBKxxM).

